package a1_BIxx_yyy;

import utils.*;

/**
 * @overview
 *    Represents a postgraduate student.
 *
 * @attributes
 *    gpa float
 *
 * @object
 *    A postgraduate student is represented by (id, name, phoneNumber, address, gpa).
 *
 * @abstract_properties
 *    P_Student /\
 *    min(id)= 1e8+1 /\
 *    mutable(gpa)=true /\ optional(gpa)=false /\ min(gpa)=0.0 /\ max(gpa)=4.0
 *
 * @author
 *    Your name here
 */
public class PostgradStudent extends Student {
    private static final double MINIMUM_GPA=0.0f;
    private static final double MAXIMUM_GPA=4.0f;
    private static final float MINIMUM_ID=1e8f+1;
    private static final float MAXIMUM_ID=1e9f;

    @DomainConstraint(type="Float", optional=false, min=MINIMUM_GPA, max=MAXIMUM_GPA)
    private float gpa;

    /**
     * @effects
     *   <pre>
     *     set necessary attributes of this as <id,name,phoneNumber,address,gpa>
     *     if those are valid
     *     else throw NotPossibleException
     *   </pre>
     */
    public PostgradStudent(
            @AttrRef("id") int id,
            @AttrRef("name") String name,
            @AttrRef("phoneNumber") String phoneNumber,
            @AttrRef("address") String address,
            @AttrRef("gpa") float gpa
        ) throws NotPossibleException {
            super(id, name, phoneNumber, address);
            if (!validate_gpa(gpa) || !validate_id(id)) {
                throw new NotPossibleException("Invalid GPA or ID for PostgradStudent" + name);
            }
            this.gpa=gpa;
    }

    // region: getters and setters
    /**
	 * @effects
     *   <pre>
	 *     return this.gpa
     *   </pre>
	 */
	@DOpt(type=OptType.Observer) @AttrRef("gpa")
	public float getGpa() {
		return this.gpa;
	}

	/**
	 * @effects
     *   <pre>
     *     return true if gpa is valid, else return false
	 *   </pre>
     */
	public boolean setGpa(float gpa) {
        if (this.validate_gpa(gpa)) {
            this.gpa=gpa;
            return true;
        }
        return false;
	}
    // endregion

    // region: other methods
	@Override
	public boolean repOK() {
        boolean valid_other_fields = super.repOK();
        boolean valid_gpa = this.validate_gpa(gpa);
        return valid_other_fields && valid_gpa;
    }

	@Override
	public String toString() {
		return String.format("PostgradStudent:<%d,%s,%s,%s,%f>",
				this.getId(),
                this.getName(),
                this.getPhoneNumber(),
                this.getAddress(),
                this.getGpa()
            );
	}
    // endregion

    // region: helper methods
    /**
     * @effects
     *   <pre>
     *     returns true if gpa is valid
     *   </pre>
     */
    private boolean validate_gpa(float gpa) {
        if (gpa < MINIMUM_GPA || gpa > MAXIMUM_GPA) {
            return false;
        }
        return true;
    }

    @Override
    @DomainConstraint(type="Integer", mutable=false, optional=false, min=MINIMUM_ID, max=MAXIMUM_ID)
    protected boolean validate_id(int id) {
        if (id < MINIMUM_ID || id > MAXIMUM_ID) {
            return false;
        }
        return true;
    }
    // endregion
}
