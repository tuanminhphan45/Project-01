package a1_BIxx_yyy;

import utils.*;

/**
 * @overview
 *    Represents an undergraduate student.
 *
 * @object
 *    A undergraduate student is represented by (id, name, phoneNum, address).
 *
 * @abstract_properties
 *    P_Student /\
 *    min(id)= 1e5 /\ max(id)= 1e8
 *
 * @author
 *    Your name here
 */

public class UndergradStudent extends Student {
    private static final float MINIMUM_ID=1e5f;
    private static final float MAXIMUM_ID=1e8f;

    /**
     * @effects
     *    set necessary attributes of this as <id,name,phoneNum,address> if those are valid, else throw NotPossibleException
     */
    public UndergradStudent(
            @AttrRef("id") int id,
            @AttrRef("name") String name,
            @AttrRef("phoneNumber") String phoneNum,
            @AttrRef("address") String address) throws NotPossibleException {
        super(id, name, phoneNum, address);
        if (!validate_id(this.getId())) {
            throw new NotPossibleException("Invalid ID for UndergradStudent" + name);
        }
    }

    // region: other methods
    @Override
    public String toString() {
        return String.format("UndergradStudent:<%s,%s,%s,%s>",
                    this.getId(),
                    this.getName(),
                    this.getPhoneNumber(),
                    this.getAddress()
                );
    }
    // endregion

    // region: helper methods
    @Override
    @DomainConstraint(type="Integer", mutable=false, optional=false, min=MINIMUM_ID, max=MAXIMUM_ID)
    protected boolean validate_id(int id) {
        if (id < MINIMUM_ID || id > MAXIMUM_ID) {
            return false;
        }
        return true;
    }
    // endregion
}
