package a1_22BI13307;

import utils.*;

/**
 * @overview
 *    Represents an undergraduate student.
 *
 * @object
 *    Undergraduate student is represented by (id, name, phoneNumber, address).
 *
 * @abstract_properties
 *    P_Student /\min(id)= 1e5 /\ max(id)= 1e8
 *
 * @author
 *    Phan Nguyen Tuan Minh - 22BI13307
 */

public class UndergradStudent extends Student {
    /**
     * 
     * @effects
     * <pre>
     *       if id,name,phoneNumber,addres are valid
     *          initialise this as <id,name,phoneNumber,address> 
     *       else 
     *          throw NotPossibleException
     * </pre>
     */
    public UndergradStudent(
        @AttrRef("id") int id,
        @AttrRef("name") String name,
        @AttrRef("phoneNumber") String phoneNumber,
        @AttrRef("address") String address) throws NotPossibleException {
    	    super(id, name, phoneNumber, address);
        if (!validate_id(id)) {
                throw new NotPossibleException("Invalid ID");
        }
        
    }


    // region: other methods
    @Override
    public String toString() {
        return String.format("UndergradStudent information:<%s,%s,%s,%s>",
                    this.getId(),
                    this.getName(),
                    this.getPhoneNumber(),
                    this.getAddress()
                );
    }
    // endregion

    // region: helper - validators
    /**
	 * @effects <pre>
	 * if id is valid
	 * 		return true
	 * else 
	 * 		return false
	 * </pre>
	 */
    @Override
    @DOpt(type=OptType.Helper)@AttrRef("id")
    @DomainConstraint(type="Integer", mutable= false, optional= false, min= 1e5f, max= 1e8f)
    protected boolean validate_id(int id) {
        return id >= 1e5f && id <= 1e8f;
    }
    // endregion
}