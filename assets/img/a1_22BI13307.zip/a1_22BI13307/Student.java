package a1_22BI13307;


import utils.*;

/**
 * @overview
 *    Represents a student in university. 
 *    There are two types:
 *          + UndergradStudent 
 *          + PostgradStudent.
 * @attributes
 *    id            Integer         int
 *    name          String
 *    phoneNumber   String
 *    address       String
 * @object
 *    A student is represented by (id, name, phoneNumber, address).
 * @abstract_properties
 *    mutable(id)=false /\ optional(id)=false /\ min(id)=1 /\ max(id)=1e9 /\
 *    mutable(name)=true /\ optional(name)=false /\ length(name)=50 /\
 *    mutable(phoneNumber)=true /\ optional(phoneNumber)=false /\ length(phoneNumber)=10 /\
 *    mutable(address)=true /\ optional(address)=false /\ length(address)=100
 *
 * @author
 *   Phan Nguyen Tuan Minh - 22BI13307
 */

public class Student implements Comparable<Student>{

    @DomainConstraint(
        type="Integer", 
        mutable=false, 
        optional=false,
        min=1, 
        max=1e9
    )
    private int id;

    @DomainConstraint(
        type="String", 
        mutable=true,
        optional=false, 
        length=50
    )
    private String name;

    @DomainConstraint(
        type="String", 
        mutable=true,
        optional=false, 
        length=10
    )
    private String phoneNumber;

    @DomainConstraint(
        type="String", 
        mutable=true,
        optional=false, 
        length=100
    )
    private String address;


    // behavior space - methods
	//public return type methodName(param_type paramName, param_type paramName2,....) {}
	//constructor - required attrs -> params
	/**
	 * 
	 * @requires  id > 1 && id < 1e9 
     *  /\ name != null && name.length() <= 50 
     *  /\ phoneNumber != null && phoneNumber.length() == 10 
     *  /\ address.length() <= 100
     * 
	 * @modifies this.name, this.phoneNumber, this.address
    /**
     * 
     * @effects
     *  <pre>
     *       if id,name,phoneNumber,address are valid
     *          initialise this as <id,name,phoneNumber,address> 
     *       else 
     *          throw NotPossibleException
     * </pre>
     */
    public Student(
            @AttrRef("id") int id,
            @AttrRef("name") String name,
            @AttrRef("phoneNumber") String phoneNumber,
            @AttrRef("address") String address
        ) throws NotPossibleException {
        if (!this.validate_id(id)) {
            throw new NotPossibleException("Invalid ID");
        }
        if (!this.validate_name(name)) {
            throw new NotPossibleException("Invalid name");
        }
        if (!this.validate_phoneNumber(phoneNumber)) {
            throw new NotPossibleException("Invalid phone number" );
        }
        if (!this.validate_address(address)) {
            throw new NotPossibleException("Invalid address");
        }
        this.id=id;
        this.name=name;
        this.phoneNumber=phoneNumber;
        this.address=address;
    }

    // getter: foreach
    /**
     * @effects
     *   <pre>
     *     return this.phoneNumber
     *   </pre>
     */
    @DOpt(type=OptType.Observer) @AttrRef("phoneNumber")
    public String getPhoneNumber() {
        return phoneNumber;
    }
    /**
     * @effects
     *   <pre>
     *     return this.address
     *   </pre>
     */
    @DOpt(type=OptType.Observer) @AttrRef("address")
    public String getAddress() {
        return address;
    }
    /**
     * @effects
     *   <pre>
     *     return this.name
     *   </pre>
     */
    @DOpt(type=OptType.Observer) @AttrRef("name")
    public String getName() {
        return name;
    }
    /**
     * @effects
     *   <pre>
     *     return this.id
     *   </pre>
     */
    @DOpt(type=OptType.Observer) @AttrRef("id")
    public int getId() {
        return id;
    }
    // endregion

    // region: setters
    /**
     * @modifies this.name
     * @effects <pre>
	 * if newName is valid
	 * 		set this.name = newName
	 * 		return true
	 * else 
	 * 		return false
     */
    @DOpt(type=OptType.Mutator) @AttrRef("name")
    public boolean setName(String name) {
        if (validate_name(name)) {
            this.name=name;
            return true;
        }
        return false;
    }
    /**
	 * @modifies this.phone
	 * @effects <pre>
	 * if newPhone is valid
	 * 		set this.name = newPhone
	 * 		return true
	 * else 
	 * 		return false
	 */
    @DOpt(type=OptType.Mutator) @AttrRef("phoneNumber")
    public boolean setPhoneNumber(String phoneNumber) {
        if (validate_phoneNumber(phoneNumber)) {
            this.phoneNumber=phoneNumber;
            return true;
        }
        return false;
    }

    /**
	 * @modifies this.address
	 * @effects <pre>
	 * if newAddress is valid
	 * 		set this.address = newAddress
	 * 		return true
	 * else 
	 * 		return false
	 */
    @DOpt(type=OptType.Mutator) @AttrRef("address")
    public boolean setAddress(String address) {
        if (validate_address(address)) {
            this.address=address;
            return true;
        }
        return false;
    }
    // endregion


	//helper - repOK
	/**
	  * 
	  * @effects <pre>
	  *  if this satisfied abstract properties
	  *  		return true
	  *  else
	  *  		return false
	  *  </pre>
	  */
    public boolean repOK() {
        boolean valid_id = validate_id(id);
        boolean valid_name = validate_name(name);
        boolean valid_phoneNumber = validate_phoneNumber(phoneNumber);
        boolean valid_address = validate_address(address);
        return valid_id && valid_name && valid_phoneNumber && valid_address;
    }

    /**
     * @effects
     *   <pre>
     *     return a string representation of this
     *   </pre>
     */
    @Override
    public String toString() {
        return String.format("Student information:<%d,%s,%s,%s>", 
                this.getId(), 
                this.getName(), 
                this.getPhoneNumber(), 
                this.getAddress());
    }

    /**
     * @effects
     *   <pre>
     *     return a string representation of this
     *   </pre>
     */
    @Override
    public int compareTo(Student input_student) throws ClassCastException, NullPointerException {
        if (input_student == null) {
            throw new NullPointerException("Input student is null");
        }
        if (!(input_student instanceof Student)) {
            throw new ClassCastException("Input student is not a Student");
        }
        return this.getName().compareTo(input_student.getName());
    }

    // region: helper - validators
    
    /**
	 * @effects <pre>
	 * if id is valid
	 * 		return true
	 * else 
	 * 		return false
	 * </pre>
	 */
    @DOpt(type=OptType.Helper)
    protected boolean validate_id(int id) {
        return id >= 1 && id <= 1e9;
    }

    /**
	 * @effects <pre>
	 * if name is valid
	 * 		return true
	 * else 
	 * 		return false
	 * </pre>
	 */
    @DOpt(type=OptType.Helper)
    protected boolean validate_name(String name) {
        return name != null && name.length() <= 50;
    }


    /**
	 * @effects <pre>
	 * if phoneNumber is valid
	 * 		return true
	 * else 
	 * 		return false
	 * </pre>
	 */
    @DOpt(type=OptType.Helper)
    protected boolean validate_phoneNumber(String phoneNumber) {
        return phoneNumber != null && phoneNumber.length() == 10;
    }
    /**
	 * @effects <pre>
	 * if address is valid
	 * 		return true
	 * else 
	 * 		return false
	 * </pre>
	 */
    @DOpt(type=OptType.Helper)
    protected boolean validate_address(String address) {
        return address != null && address.length() <= 100;
    }
    // endregion
}