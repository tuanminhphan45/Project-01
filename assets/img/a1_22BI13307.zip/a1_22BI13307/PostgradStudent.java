package a1_22BI13307;

import utils.*;

/**
 * @overview
 *    Represents a postgraduate student.
 * @attributes
 *    gpa float
 * @object
 *    A postgraduate student is represented by (id, name, phoneNumber, address, gpa).
 * @abstract_properties
 *    P_Student /\
 *    min(id)= 1e8+1 /\phoneNumer
 *    mutable(gpa)=true /\ optional(gpa)=false /\ min(gpa)=0.0 /\ max(gpa)=4.0
 * @author
 *    Phan Nguyen Tuan Minh - 22BI13307
 */
public class PostgradStudent extends Student {

    @DomainConstraint(type="Float", optional=false, min=0.0f, max=4.0f)
    private float gpa;

    /**
     * @effects
     *   <pre>
     *      if id,name,phoneNumber,address,gpa are valid
     *          initialise this as <id,name,phoneNumber,address,gpa> 
     *      else 
     *          throw NotPossibleException
     *   </pre>
     */
    public PostgradStudent(
            @AttrRef("id") int id,
            @AttrRef("name") String name,
            @AttrRef("phoneNumber") String phoneNumber,
            @AttrRef("address") String address,
            @AttrRef("gpa") float gpa
        ) throws NotPossibleException {
    			super(id, name, phoneNumber, address);
            if (!validate_gpa(gpa) || !validate_id(id)) {
                throw new NotPossibleException("Invalid GPA or ID");
            }
            
            this.gpa=gpa;
    }

    // region: getters
    /**
	 * @effects
     *   <pre>
	 *     return this.gpa
     *   </pre>
	 */
	@DOpt(type=OptType.Observer) @AttrRef("gpa")
	public float getGpa() {
		return this.gpa;
	}
    
    // endregion

    // region: setters
	/**
	 * @effects
     * <pre>
     * if gpa is valid
     *    return true
     * else 
     *    return false
	 * </pre>
     */
    @DOpt(type=OptType.Mutator) @AttrRef("gpa")
	public boolean setGpa(float gpa) {
        if (this.validate_gpa(gpa)) {
            this.gpa=gpa;
            return true;
        }
        return false;
	}
    // endregion

    //region: helper - repOK
	 /**
	  * @effects <pre>
	  *  if this satisfied abstract properties
	  *  		return true
	  *  else
	  *  		return false
	  *  </pre>
	  */
	@Override
    @DOpt(type=OptType.Helper)
	public boolean repOK() {
        boolean valid_other_fields = super.repOK();
        boolean valid_gpa = this.validate_gpa(gpa);
        return valid_other_fields && valid_gpa;
    }

	@Override
	public String toString() {
		return String.format("PostgradStudent information:<%d,%s,%s,%s,%f>",
				this.getId(),
                this.getName(),
                this.getPhoneNumber(),
                this.getAddress(),
                this.getGpa()
            );
	}
    // endregion

    // region: helper - validators
    /**
	 * @effects <pre>
	 * if id is valid
	 * 		return true
	 * else 
	 * 		return false
	 * </pre>
	 */
    @DOpt(type=OptType.Helper) @AttrRef("gpa")
	private boolean validate_gpa(float gpa) {
	        return gpa >= 0.0f && gpa <= 4.0f;
	    }
    
    /**
	 * @effects <pre>
	 * if id is valid
	 * 		return true
	 * else 
	 * 		return false
	 * </pre>
	 */
    @Override
    @DOpt(type=OptType.Helper) @AttrRef("id")
    @DomainConstraint(type="Integer", mutable=false, optional=false, min=1e8f+1, max=1e9f)
    protected boolean validate_id(int id) {
        return id >= 1e8 + 1 && id <= 1e9;
    }
    // endregion
}

